package ingredients.instanceIngredient;

/**
 * enumeration des types d'ingredients
 */
public enum TypeIngredient {
    FRUIT, LEGUME, VIANDE, LAITIER, EPICE
}
