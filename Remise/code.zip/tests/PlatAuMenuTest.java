package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlatAuMenuTest {

    @Test
    void testToString() {
    }

    @Test
    void getCode() {
    }

    @Test
    void setCode() {
    }

    @Test
    void getDescription() {
    }

    @Test
    void setDescription() {
    }

    @Test
    void getPrix() {
    }

    @Test
    void setPrix() {
    }

    @Test
    void getProportion() {
    }

    @Test
    void getRecette() {
    }

    @Test
    void setRecette() {
    }
}