package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlatSanteTest {

    @Test
    void testToString() {
    }

    @Test
    void getKcal() {
    }

    @Test
    void setKcal() {
    }

    @Test
    void getChol() {
    }

    @Test
    void setChol() {
    }

    @Test
    void getGras() {
    }

    @Test
    void setGras() {
    }
}