package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChefTest {



    @Test
    void getInstance() {
    }

    @Test
    void getNom() {
    }

    @Test
    void setNom() {
    }

    @Test
    void verifIngredient() {
    }

    @Test
    void cuisiner() {
    }

    @Test
    void testToString() {
    }
}