package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventaireTest {

    @Test
    void getInstance() {
    }

    @Test
    void ajoutIngredient() {
    }

    @Test
    void testAjoutIngredient() {
    }

    @Test
    void ajouter() {
    }

    @Test
    void getIngredient() {
    }

    @Test
    void getSize() {
    }

    @Test
    void getIngredientQuantite() {
    }

    @Test
    void consommerRecette() {
    }

    @Test
    void vider() {
    }

    @Test
    void testToString() {
    }
}