package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlatEnfantTest {

    @Test
    void getProportion() {
    }

    @Test
    void setProportion() {
    }

    @Test
    void testToString() {
    }
}