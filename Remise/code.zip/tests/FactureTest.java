package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FactureTest {

    @Test
    void associerClient() {
    }

    @Test
    void associerChef() {
    }

    @Test
    void sousTotal() {
    }

    @Test
    void total() {
    }

    @Test
    void payer() {
    }

    @Test
    void fermer() {
    }

    @Test
    void ouvrir() {
    }

    @Test
    void getEtat() {
    }

    @Test
    void ajoutePlat() {
    }

    @Test
    void testToString() {
    }

    @Test
    void genererFacture() {
    }

    @Test
    void subscribe() {
    }
}