package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlatSanteBuilderTest {

    @Test
    void buildKcal() {
    }

    @Test
    void buildChol() {
    }

    @Test
    void buildGras() {
    }

    @Test
    void clear() {
    }

    @Test
    void getPlatSante() {
    }
}