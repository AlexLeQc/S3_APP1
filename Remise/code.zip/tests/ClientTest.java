package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    @Test
    void getIdClient() {
    }

    @Test
    void setIdClient() {
    }

    @Test
    void getNom() {
    }

    @Test
    void setNom() {
    }

    @Test
    void getNumeroCarteCredit() {
    }

    @Test
    void setNumeroCarteCredit() {
    }

    @Test
    void testToString() {
    }
}