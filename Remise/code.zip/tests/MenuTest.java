package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MenuTest {

    @Test
    void getInstance() {
    }

    @Test
    void getDescription() {
    }

    @Test
    void setDescription() {
    }

    @Test
    void ajoute() {
    }

    @Test
    void position() {
    }

    @Test
    void platCourant() {
    }

    @Test
    void positionSuivante() {
    }

    @Test
    void positionPrecedente() {
    }

    @Test
    void testToString() {
    }
}